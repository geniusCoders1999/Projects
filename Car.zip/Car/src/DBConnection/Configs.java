package DBConnection;

public class Configs {

	public String dbhost = "localhost";
	public String dbport = "3306";
	public String dbuser = "root";
	public String dbpassword = "123456";
	public String dbase = "genius";
	
}
