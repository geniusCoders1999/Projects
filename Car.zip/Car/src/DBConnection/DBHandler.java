package DBConnection;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class DBHandler extends Configs {
	
	Configs configs = new Configs();
	Connection dbConnection;
	public Connection getConnection()  
	{
		String connectionString = "jdbc:mysql://"+ configs.dbhost + ":"+ configs.dbport +"/"+ configs.dbase+"?autoReconnect=true&useSSL=false";
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			dbConnection =  (Connection) DriverManager.getConnection(connectionString, configs.dbuser, configs.dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dbConnection;
		
	}
	

	
}
