package Controllers;

import javafx.event.*;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import DBConnection.DBHandler;

public class LoginController implements Initializable {

	  @FXML
	    private AnchorPane LoginMain;

	    @FXML
	    private JFXTextField TextUsername;

	    @FXML
	    private JFXPasswordField TextPassword;

	    @FXML
	    private JFXButton ButtonSignUp;

	    @FXML
	    private JFXButton ButtonLogin;

	    @FXML
	    private JFXCheckBox CheckRemember;

	    @FXML
	    private JFXButton ButtonForgot;
	    @FXML
	    private ImageView Progress;
	    private Connection connection; 
	    private DBHandler dbHandler;
	    private PreparedStatement pst;
        

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		TextUsername.setStyle("-fx-text-inner-color : #a0b2ab;");
		TextPassword.setStyle("-fx-text-inner-color : #a0b2ab;");
        
		dbHandler = new DBHandler();
	}
	
	 @FXML
	     public void LoginAction (ActionEvent event)  {
		 Progress.setVisible(true);
        PauseTransition pt = new PauseTransition();
        pt.setDuration(Duration.seconds(1));
        pt.setOnFinished(cv -> {
        	//System.out.println("Login Succefully");
        });
        pt.play();
        // retrieve Data from database
        connection = dbHandler.getConnection();
        String qt = "SELECT * FROM youtubers where names = ? and password=? ";
        try {
			pst = (PreparedStatement) connection.prepareStatement(qt);
			pst.setString(1, TextUsername.getText());
			pst.setString(2, TextPassword.getText());
			ResultSet rs = pst.executeQuery();
			
			int count =0;
			while (rs.next())
			{
				count = count+1;
			}
			if (count ==1)
			{
				System.out.println("Login succefully");
			}else
			{
				System.out.println("Username and Password is not Correct");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        finally 
        {
        	try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        
        
	    }
	 @FXML
	    public void SignUpAction(ActionEvent event) throws IOException {
         LoginMain.getScene().getWindow().hide();
         Stage signup = new Stage();
         Parent root = FXMLLoader.load(getClass().getResource("/FXML/SingUP.fxml"));
         Scene scene = new Scene(root);
         signup.setScene(scene);
         signup.show();
         signup.setResizable(false);
	    }
	 
	 

}
