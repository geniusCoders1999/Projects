package Controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextField;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import DBConnection.DBHandler;
public class SignupController implements Initializable {

	    @FXML
	    private AnchorPane SignUP; 
	    @FXML
	    private JFXTextField TextUsername;
	    @FXML
	    private JFXPasswordField TextPassword;
	    @FXML
	    private JFXRadioButton CheckMale;
	    @FXML
	    private JFXRadioButton CheckFemale;
	    @FXML
	    private JFXTextField TextLocation;
	    @FXML
	    private JFXButton ButtonSignUP;
	    @FXML
	    private JFXButton ButtonLogin;
	    @FXML
	    private ImageView Progress;
	 
	    private Connection connection; 
	    private DBHandler dbHandler;
	    private PreparedStatement pst;
	    
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		TextUsername.setStyle("-fx-text-inner-color : #a0b2ab;");
		TextPassword.setStyle("-fx-text-inner-color : #a0b2ab;");
		TextLocation.setStyle("-fx-text-inner-color : #a0b2ab;");
		
		dbHandler = new DBHandler();
		
	}
	  @FXML
	  public void SignUP(ActionEvent event) {
		    Progress.setVisible(true);
	        PauseTransition pt = new PauseTransition();
	        pt.setDuration(Duration.seconds(1));
	        pt.setOnFinished(cv -> {
	        	System.out.println("Sign UP Succefully");
	        });
	        pt.play();
	        
	        //Saving Data
	        String insert ="INSERT INTO youtubers (names,password,gender,adress)"+ "VALUES (?,?,?,?)";
	        connection = dbHandler.getConnection();
	        try {
				pst = (PreparedStatement) connection.prepareStatement(insert);
			} catch (SQLException e) {
				e.printStackTrace();
			}
	        try {
				pst.setString(1, TextUsername.getText());
				pst.setString(2, TextPassword.getText());
				pst.setString(3, getGender() );
				pst.setString(4, TextLocation.getText());
				pst.executeUpdate();
				

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	    }
	  @FXML
	   public void LoginAction(ActionEvent event) throws IOException {
		  SignUP.getScene().getWindow().hide();
		  Stage login = new Stage();
		  Parent root = FXMLLoader.load(getClass().getResource("/FXML/LoginMain.fxml"));
		  Scene scene= new Scene(root);
		  login.setScene(scene);
		  login.show();
		  login.setResizable(false);
		  
	    }
	  public String getGender()
	  {
		String gen ="";
		if(CheckMale.isSelected())
		{
			gen = "Male";
		}else if (CheckFemale.isSelected())
		{
			gen ="Female";
		}
			
		  return gen;
		  
	  }
	

}
