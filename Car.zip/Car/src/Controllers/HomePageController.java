package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXButton;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

public class HomePageController implements Initializable
{
	 	@FXML private AnchorPane HolderPane;
	 	 AnchorPane home;
	    @FXML private JFXButton ButtonMyCras;
	    @FXML private JFXButton ButtonHome;
	    @FXML private JFXButton ButtonAbout;
	    @FXML private JFXButton ButtonContact;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		createPage();
	}
	private void setNode (Node node )
	{
		HolderPane.getChildren().clear();
		HolderPane.getChildren().add(node);
		
		FadeTransition ft = new FadeTransition(Duration.millis(1500));
		ft.setNode(node);
		ft.setFromValue(0.1);
		ft.setToValue(1);
		ft.setCycleCount(1);
		ft.setAutoReverse(false);
		ft.play();
		
	}
	private void createPage() {
		try {
			home = FXMLLoader.load(getClass().getResource("/FXML/Home.fxml"));
			setNode(home);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
